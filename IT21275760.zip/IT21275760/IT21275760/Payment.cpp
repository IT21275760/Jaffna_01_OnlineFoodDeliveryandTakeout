#include "Payment.h"
#include<iostream>
using namespace std;

Payment::Payment()
{
}

void Payment::AsignCardDetails(int id, int C_no, int cvv, int CED, char chn[])
{
	P_ID = id;
	CardNumber = C_no;
	CVV = cvv;
	CardExpireDate = CED;
	strcpy(CardHolderName, chn);
}

void Payment::DiscountIs()
{
	cout << "discount is 25%" << endl;
}

float Payment::CalculateTotal()
{
	total = Amount * (25.00 / 100.00);
	return total;
}

void Payment::SetAmount(float amount)
{
	Amount = amount;
}