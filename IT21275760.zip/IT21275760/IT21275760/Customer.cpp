#include "Customer.h"

Customer::Customer()
{
}

void Customer::CreateAccount()
{
}

void Customer::Login()
{
}

void Customer::ViewFood()
{
}

void Customer::PlaceOrder()
{
}

void Customer::CustomizFood()
{
}

void Customer::SelectDelivery()
{
}

void Customer::SelectTakeout()
{
}

void Customer::PayPayment()
{
}

void Customer::CancelOrder()
{
}

void Customer::GiveFeedback()
{
}
