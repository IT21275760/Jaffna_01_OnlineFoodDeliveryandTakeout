#pragma once
#include<cstring>
#include"Customer.h"
class Payment
{
private:
	int P_ID;
	int CardNumber;
	int CVV;
	int CardExpireDate;
	char CardHolderName[40];
	float Amount;
	float Discount;
	float total;
	Customer* c1;
	Order* Or;

public:
	Payment();
	void AsignCardDetails(int id, int C_no, int cvv, int CED, char chn[]);
	void DiscountIs();
	float CalculateTotal();
	void SetAmount(float amount);

};