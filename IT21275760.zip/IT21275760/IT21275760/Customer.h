#pragma once
#include"Payment.h"
class Customer
{
private:
	int C_ID;
	char Password[8];
	char Name[40];
	char Address[20];
	char DOB[20];
	int Age;
	int PhoneNumber;
	FoodItem* F_it;
	Order* Or;
	Payment* p1;

public:
	Customer();
	void CreateAccount();
	void Login();
	void ViewFood();
	void PlaceOrder();
	void CustomizFood();
	void SelectDelivery();
	void SelectTakeout();
	void PayPayment();
	void CancelOrder();
	void GiveFeedback();
};